# betterbook
Making Facebook Better

## What is this?
This is a Firefox (and maybe Chrome, although yet untested) extension to make Facebook better.

## What does this do?
It currently does these things:
- Adds a warning on top of the news feed to not spend too much time on Facebook
- Hides the "Trending" section
- Clears the page and tells you to do something else after a certain amount of time (with a minute warning)
